# ans.fhir.fr.test.ror#0.1.0: Démonstration - Modèle Logique ROR dérivant du MOS(fr)

## Pages

* [Accueil](index.md)
* [Historique des versions](change-log.md)
* [Pourquoi le Modèle Logique HL7 ?](avantages-ml.md)
* [Fonctionnalités disponibles pour le ROR](fonctionnalites-ror.md)
* [Résumé des artefacts](artifacts.md)

## Resources

### ImplementationGuides

* [Démonstration - Modèle Logique ROR dérivant du MOS](ImplementationGuide-ans.fhir.fr.test.ror.md)
