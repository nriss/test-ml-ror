# ans.fhir.fr.test.ror#0.1.0: Démonstration - Modèle Logique ROR dérivant du MOS(fr)

## Pages

* [Accueil](index.md)
* [Historique des versions](change-log.md)
* [Pourquoi le Modèle Logique HL7 ?](avantages-ml.md)
* [Fonctionnalités disponibles pour le ROR](fonctionnalites-ror.md)
* [Résumé des artefacts](artifacts.md)

## Resources

### ValueSets

* [ROR - Secteur d'activité (restreint)](ValueSet-vs-ror-secteur-activite.md)

### Logicals

* [ROR - Entité Géographique](StructureDefinition-ror-entite-geographique.md)
* [ROR - Offre Opérationnelle](StructureDefinition-ror-offre-operationnelle.md)
* [ROR - Organisation Interne](StructureDefinition-ror-organisation-interne.md)

### ImplementationGuides

* [Démonstration - Modèle Logique ROR dérivant du MOS](ImplementationGuide-ans.fhir.fr.test.ror.md)
